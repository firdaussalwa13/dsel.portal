DSEL ONLINE DEPLOYMENT KIT

ISI:
- index.html: prototipe website responsif, fokus pembelajaran PJOK 4 pertemuan.
- data/*.csv: template awal untuk diimpor ke Google Sheets.

MENJALANKAN SECARA LOKAL:
1. Ekstrak ZIP.
2. Buka index.html di Chrome/Edge.

MEMPUBLIKASIKAN ONLINE:
Pilihan sederhana:
A. Google Sites: buat situs baru, tiru struktur dan desain dari prototipe. Google Sites tidak mengimpor HTML ini secara langsung.
B. Hosting statis: unggah index.html ke layanan hosting statis yang kamu pilih. Setelah itu kamu memperoleh URL publik. File CSV dapat diimpor terpisah ke Google Sheets.

BATASAN:
- Form refleksi di index.html masih demo lokal, tidak mengirim data.
- Mode Guru bukan login dan tidak aman untuk data pribadi.
- Tidak ada database online/API yang terpasang.
- Data contoh harus diganti dengan data sekolah.
- Untuk hak akses guru/siswa yang sesungguhnya, atur izin Google Drive/Sheets/Forms atau buat aplikasi dengan autentikasi.

SARAN PRIVASI:
Gunakan kode peserta, minimalkan data pribadi, dan batasi dokumen guru.
